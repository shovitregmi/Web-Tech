 
let numbers = [25, 112, 708, 34, 90, 23, 47, 65, 99, 33];
 
let largest = Math.max(...numbers);
let smallest = Math.min(...numbers);
 
console.log("Array:", numbers);
console.log("Largest element:", largest);
console.log("Smallest element:", smallest);

 // Define a 5-digit number
let number = 69697;


let numString = number.toString();
let digits = numString.split('').map(Number); 
 
let largestDigit = Math.max(...digits);
let smallestDigit = Math.min(...digits);

 
console.log("Number:", number);
console.log("Digits:", digits);
console.log("Largest digit:", largestDigit);
console.log("Smallest digit:", smallestDigit);