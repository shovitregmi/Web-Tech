 // 1. Multiple Ways of Creating an Object
console.log("Multiple Ways of Creating an Object:");

// Using object literal (Built-in approach)
const objLiteral = { a: 1, b: 2, c: 3 };
console.log("Object Literal:", objLiteral);

// Using Object constructor (Built-in approach)
const objConstructor = new Object();
objConstructor.a = 1;
objConstructor.b = 2;
objConstructor.c = 3;
console.log("Object Constructor:", objConstructor);

// Using Object.create() (Built-in approach)
const objCreate = Object.create(Object.prototype);
objCreate.a = 1;
objCreate.b = 2;
objCreate.c = 3;
console.log("Object.create():", objCreate);

// Using function constructor (User-defined approach)
function Person(name, age) {
  this.name = name;
  this.age = age;
}
const personObj = new Person("John", 30);
console.log("Function Constructor (User-defined):", personObj);

// Starting with an object for further operations
let obj = { a: 1, b: 2, c: 3 };
console.log("\nInitial Object:", obj);

// 2. Check Prototypes of Object()
console.log("\nChecking Prototype:");
console.log("Is obj's prototype Object.prototype?", Object.getPrototypeOf(obj) === Object.prototype); // true

// 3. Add Data as First Element
// Objects are unordered, but we simulate adding a property at the "beginning" with Object.assign()
const newFirstProp = { x: 0 };
obj = Object.assign(newFirstProp, obj);
console.log("\nAfter adding 'x: 0' as first property:", obj); // { x: 0, a: 1, b: 2, c: 3 }

// 4. Add Data as Last Element
// Add a new property
obj.d = 4;
console.log("After adding 'd: 4' as last property:", obj); // { x: 0, a: 1, b: 2, c: 3, d: 4 }

// 5. Remove First Element
// Delete the first property based on key order
const firstKey = Object.keys(obj)[0];
delete obj[firstKey];
console.log("After removing first property:", obj); // { a: 1, b: 2, c: 3, d: 4 }

// 6. Remove Last Element
// Delete the last property based on key order
const lastKey = Object.keys(obj)[Object.keys(obj).length - 1];
delete obj[lastKey];
console.log("After removing last property:", obj); // { a: 1, b: 2, c: 3 }

// 7. Add Data at Middle Position
// Add a property and reorder keys to simulate middle insertion
obj.y = 2.5;
// Reorder to place 'y' after the second property
const keys = Object.keys(obj);
const indexToInsert = 2;
const newObj = {};
keys.slice(0, indexToInsert).forEach(key => newObj[key] = obj[key]);
newObj.y = 2.5;
keys.slice(indexToInsert).forEach(key => newObj[key] = obj[key]);
obj = newObj;
console.log("After adding 'y: 2.5' at middle:", obj); // { a: 1, b: 2, y: 2.5, c: 3 }

// 8. Remove Data from Middle Position
// Delete a specific property (e.g., 'y')
delete obj.y;
console.log("After removing 'y' from middle:", obj); // { a: 1, b: 2, c: 3 }

// 9. Display Data with for-loop
console.log("\nDisplaying Object with for-loop:");
for (const key in obj) {
  if (obj.hasOwnProperty(key)) {
    console.log(`${key}: ${obj[key]}`);
  }
}
// Output: a: 1, b: 2, c: 3

 
console.log("\nSingle Element (key 'b'):", obj.b);  

 
console.log("\nObject Destructuring:");
const { a, b, ...rest } = obj;
console.log("a:", a);  
console.log("b:", b);  
console.log("rest:", rest); 