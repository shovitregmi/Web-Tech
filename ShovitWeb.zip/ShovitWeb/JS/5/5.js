// 1. Multiple Ways of Creating an Array
console.log("Multiple Ways of Creating an Array:");

// Using array literal
const arrLiteral = [1, 2, 3, 4];
console.log("Array Literal:", arrLiteral);

// Using Array constructor
const arrConstructor = new Array(1, 2, 3, 4);
console.log("Array Constructor:", arrConstructor);

// Using Array.of() method
const arrOf = Array.of(1, 2, 3, 4);
console.log("Array.of():", arrOf);

// Using Array.from() method
const arrFrom = Array.from([1, 2, 3, 4]);
console.log("Array.from():", arrFrom);

// Starting with an array for further operations
let arr = [2, 3, 4];
console.log("\nInitial Array:", arr);

// 2. Check Prototypes of Array()
console.log("\nChecking Prototype:");
console.log("Is arr's prototype Array.prototype?", Object.getPrototypeOf(arr) === Array.prototype); // true

// 3. Add Data as First Element (unshift)
arr.unshift(1);
console.log("\nAfter unshift(1):", arr); // [1, 2, 3, 4]

// 4. Add Data as Last Element (push)
arr.push(5);
console.log("After push(5):", arr); // [1, 2, 3, 4, 5]

// 5. Remove First Element (shift)
arr.shift();
console.log("After shift():", arr); // [2, 3, 4, 5]

// 6. Remove Last Element (pop)
arr.pop();
console.log("After pop():", arr); // [2, 3, 4]

// 7. Add Data at Middle Position (splice)
arr.splice(2, 0, 3.5); // Add 3.5 at index 2
console.log("After splice(2, 0, 3.5):", arr); // [2, 3, 3.5, 4]

// 8. Remove Data from Middle Position (splice)
arr.splice(2, 1); // Remove element at index 2
console.log("After splice(2, 1):", arr); // [2, 3, 4]

// 9. Demonstrate forEach(), map(), filter(), reduce()
console.log("\nArray Methods Demonstration:");

// forEach() - Logs each element
console.log("forEach():");
arr.forEach((element) => console.log(element));
// Output: 2, 3, 4

// map() - Doubles each element
const doubled = arr.map((element) => element * 2);
console.log("map() (doubled):", doubled); // [4, 6, 8]

// filter() - Filters even numbers
const evens = arr.filter((element) => element % 2 === 0);
console.log("filter() (evens):", evens); // [2, 4]

// reduce() - Sums all elements
const sum = arr.reduce((accumulator, element) => accumulator + element, 0);
console.log("reduce() (sum):", sum); // 9

// 10. Display Data with for-loop
console.log("\nDisplaying Array with for-loop:");
for (let i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}
// Output: 2, 3, 4

// 11. Check Length of Array
console.log("\nLength of Array:", arr.length); // 3

// 12. Display Single Element without Loop
console.log("\nSingle Element (index 1):", arr[1]); // 3

// 13. Demonstrate Array Destructuring
console.log("\nArray Destructuring:");
const [first, second, ...rest] = arr;
console.log("First:", first); // 2
console.log("Second:", second); // 3
console.log("Rest:", rest); // [4]